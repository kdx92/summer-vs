package com.managementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerResearchApplicationTests {

    @Test
    void contextLoads() {
    }

}
